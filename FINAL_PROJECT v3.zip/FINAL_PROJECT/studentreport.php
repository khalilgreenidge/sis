<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
<link rel="shortcut icon" href="imgs/titleimg.gif" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

<div id = "header">
	<img src="imgs/bcclogo.gif" alt="log" />
	<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
	<p class="msg" style="float: right;">Signed in as <?php echo "<b>".ucfirst($_SESSION["user"]).".</b>";?></p>
</div>

<div id = "menu">
<?php include("menu.php") ?>
</div>

<div id = "content">
	<h1>Barbados Community College - Tutor Portal</h1>
	
<form method = "get" action = "studentfinalreport.php">
<?php

$rowNum = 0;
$rem = 0;

$con = mysql_connect("localhost","root","") or die(mysql_error());

mysql_select_db("my course") or die(mysql_error());

$result = mysql_query("SELECT * FROM students ORDER BY last_name ASC") or die (mysql_error());

echo "<table border = '1'>
<tr>
<th>Student Identification Number</th>
<th>First Name </th>
<th>Last Name</th>
</tr>";

while($row = mysql_fetch_array($result)){
	$rowNum++;
	$rem = $rowNum % 2;
			
	//CREATES AN ALTERNATING COLOUR
	if($rem == 0){
		echo "<tr style='background-color: #FA8258;'>";
		echo "<td>".$row['student_id']."</td>";
		echo "<td>".$row['first_name']."</td>";
		echo "<td>".$row['last_name']."</td>";	
		echo "</tr>";
	}
	else{
		echo "<tr>";
		echo "<td>" . $row['student_id'] . "</td>";
		echo "<td>" . $row['first_name'] . "</td>";
		echo "<td>" . $row['last_name'] . "</td>";
		echo "<tr>";
	}
}
echo "</table>";

$result1 = mysql_query("SELECT student_id FROM students") or die(mysql_error());
echo "<br/>";
echo"<select name =\"student_id\">";
while($row = mysql_fetch_array($result1)){
	echo"<option value = ".$row["student_id"].">".$row["student_id"]."</option>";
}
	
mysql_close();
echo"</select>";
?>

<hr>

<br/>

<button type = "submit">PRINT</button> 
<button type = "reset" value = "Reset">RESET</button>
</form>
</div>


<div id = "footer">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
	developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>
