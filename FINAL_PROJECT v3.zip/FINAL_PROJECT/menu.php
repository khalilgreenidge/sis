<ul>
	<li><a href="login.php">Home</a></li>
	<li><a href="addstudent.php">Add Student<a/></li>
	<li><a href="updatesemestermarks.php">Update Semester Marks</a></li>
	<li><a href="updatefinalmarks.php">Update Final Marks</a></li>
	<li><a href="deletestudent.php">Delete Student Record</a></li>
	<li><a href="studentlist.php">Student List</a></li>
	<li><a href="studentreport.php">Student Report<a></li>
	<li><a href="about.php">About</a></li>
</ul>