<?php
	session_start();
	
	//DESTROY SESSION
	
	session_destroy();
	
	header("Location: login.php");
?>
		
		
		
