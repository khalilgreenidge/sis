<?php session_start();  ?>
<!DOCTYPE html>
<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
<link rel="shortcut icon" href="imgs/titleimg.gif" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

<div id = "header">
	<img src="imgs/bcclogo.gif" alt="log" />
	<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
	<p class="msg" style="float: right;">Signed in as <?php echo "<b>".ucfirst($_SESSION["user"]).".</b>";?></p>
</div>

<div id = "menu">
<?php include("menu.php") ?>
</div>

<div id = "content">
	<h1>Barbados Community College - Tutor Portal</h1>
	
	<h2>STUDENT FINAL REPORT</h2>
	<?php
$con = mysql_connect("localhost", "root", "") or die(mysql_error());
mysql_select_db("my course") or die(mysql_error());

$id = $_GET["student_id"];
$semester = 0;
$final = 0;

echo "<h3>Showing the results for -- ".$id.":</h3>";
echo "<br/><br/>";

$result = mysql_query("SELECT * FROM students WHERE student_id = '$id'") or die(mysql_error());

echo "<table border = ''>
<tr>
<th>Student ID</th>
<th>First Name </th>
<th>Last Name</th>
<th>Test 1</th>
<th>Test 2</th>
<th>Assignment</th>
<th>Project</th>
<th>Paper 1</th>
<th>Paper 2</th>
<th>Semester Percentage (40%)</th>
<th>Final Percentage</th>
<th>Grade</th>
</tr>";

while($row = mysql_fetch_array($result)){
$semester = (($row['test_1']/100*0.10) + ($row['test_2']/100*0.10) + ($row['assignment']/100*0.10) + ($row['project']/100*0.10))/0.40*100;
$final = (($row['paper_1']/100*0.30) + ($row['paper_2']/100*0.30))/0.60*100;
$final = ($semester + $final) / 200 * 100;
echo "<tr>";
echo "<td>" . $row['student_id'] . "</td>";
echo "<td>" . $row['first_name'] . "</td>";
echo "<td>" . $row['last_name'] . "</td>";
echo "<td style='text-align: right'>" . $row['test_1'] . "</td>";
echo "<td style='text-align: right'>" . $row['test_2'] . "</td>";
echo "<td style='text-align: right'>" . $row['assignment'] . "</td>";
echo "<td style='text-align: right'>" . $row['project'] . "</td>";
echo "<td style='text-align: right'>" . $row['paper_1'] . "</td>";
echo "<td style='text-align: right'>" . $row['paper_2'] . "</td>";
echo "<td style='text-align: right'>" . number_format($semester,2) . "</td>";
echo "<td style='text-align: right'>" . number_format($final,2) . "</td>";

if ($final >= 85 && $final <=100){
  echo "<td>" . "A+" . "</td>";
}
else if ($final >= 75 && $final <=84){
  echo "<td>" . "A" . "</td>";
}
else if ($final >= 65 && $final <=74){
  echo "<td>" . "B+" . "</td>";
}
else if ($final >= 55 &&  $final <=64){
  echo "<td>" . "B" . "</td>";
}
else if ($final >= 45 && $final <=54){
  echo "<td>" . "C" . "</td>";
}
else if ($final >= 0 &&  $final <=44){
  echo "<td>" . "F" . "</td>";
}

echo "</tr>";
}
echo "</table>";


mysql_close();

?>
</form>
<br/><br/>
<hr/>
</div>


<div id = "footer">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
	Developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>
