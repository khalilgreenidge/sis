<!DOCTYPE html>
<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
<link rel="shortcut icon" href="imgs/titleimg.gif" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

<div id = "header">
	<img src="imgs/bcclogo.gif" alt="log" />
	<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
</div>
<hr/>

<div id = "content">
	<h1>Sign up</h1><br/>
	<div id='login'>
		<form method='post' action='mail.php'>
			Tutor ID: <input type='text' name='ID' /><br/>
			User name: <input type='text' name='user' /><br/>
			First name: <input type='text' name='firstname' /><br/>
			Last name: <input type='text' name='lastname' /><br/>
			Password: <input type='password' name='pwd' /><br/>
			Confirm password: <input type='password' name='pwd' /><br/>
			Male <input type="radio" name="gender" value="Mr." /> 
			Female <input type="radio" name="gender" value="Mrs." /></br>
			Email: <input type="email" name="email" /><br/>
			<button type="submit">Submit</button>
		</form>
	</div>
</div>


<div id = "footer">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
	developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>
