<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
<link rel="shortcut icon" href="imgs/titleimg.gif" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

<div id = "header">
	<img src="imgs/bcclogo.gif" alt="log" />
	<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
	<p class="msg" style="float: right;">Signed in as <?php echo "<b>".ucfirst($_SESSION["user"]).".</b>";?></p>
</div>

<div id = "menu">
<?php include("menu.php") ?>
</div>

<?php
	$msg = $id = $mark = $percent = $error = "";
	
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		
		//GET FORM DATA
		$id = $_POST["ID"];
		$mark = $_POST["mark"];
		$percent = $_POST["percent"];
		
		//ESTABLISH CONNECTION
		$con = mysql_connect("localhost", "root", "");
		
		//CONNECT TO DB
		$db = mysql_select_db("my course");
		
		//EXTRACT RESULTSET
		$rs = mysql_query("UPDATE students SET $mark=$percent WHERE student_id=$id ");
		
		if(!$con || !$db || !$rs){
			$error = "Error: ".mysql_error();
			
		}
		else{
			$msg = "Student information has been updated!";
		}
	}
?>

<div id = "content">
	<h1>Update a student's semester marks</h1>
	<br/>
	<?php
		$rowNum = 0;
		$rem = 0;
		
		//ESTABLISH CONNECTION
		$con = mysql_connect("localhost", "root", "");
		
		//CONNECT TO DB
		$db = mysql_select_db("my course");
		
		//EXTRACT RESULTSET
		$rs1 = mysql_query("SELECT * FROM students ORDER BY last_name ASC");
		
		if(!$con || !$db || !$rs1){
			$error = "Error: ".mysql_error();
		}
		
		echo "<table border='1'>
		<tr>
		<th>Student ID</th><th>First Name</th><th>Last Name</th>
		<th>Test 1%</th><th>Test 2%</th><th>Assignment %</th><th>Project %</th><th>Paper 1 %</th><th>Paper 2%</th>
		</tr>
		";
		
		
		while($row = mysql_fetch_array($rs1) ){
			$rowNum++;
			$rem = $rowNum % 2;
			
			//CREATES AN ALTERNATING COLOUR
			if($rem == 0){
				echo "<tr style='background-color: #FA8258;'>";
				echo "<td>".$row['student_id']."</td>";
				echo "<td>".$row['first_name']."</td>";
				echo "<td>".$row['last_name']."</td>";
				echo "<td style='text-align: right'>".$row['test_1']."</td>";
				echo "<td style='text-align: right'>".$row['test_2']."</td>";
				echo "<td style='text-align: right'>".$row['assignment']."</td>";
				echo "<td style='text-align: right'>".$row['project']."</td>";
				echo "<td style='text-align: right'>".$row['paper_1']."</td>";
				echo "<td style='text-align: right'>".$row['paper_2']."</td>";
				echo "</tr>";
			}
			else{
				echo "<tr>";
				echo "<td>".$row['student_id']."</td>";
				echo "<td>".$row['first_name']."</td>";
				echo "<td>".$row['last_name']."</td>";
				echo "<td style='text-align: right'>".$row['test_1']."</td>";
				echo "<td style='text-align: right'>".$row['test_2']."</td>";
				echo "<td style='text-align: right'>".$row['assignment']."</td>";
				echo "<td style='text-align: right'>".$row['project']."</td>";
				echo "<td style='text-align: right'>".$row['paper_1']."</td>";
				echo "<td style='text-align: right'>".$row['paper_2']."</td>";
				echo "</tr>";
			}
		}
		echo "</table>";
		
	?>
	<br/>
	<hr/>
	
	<h2>Choose an ID and type of mark to be updated.</h2>
	<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>">
		Student's ID:
		<select name="ID">
			<option value="">--ID--</option>
			<?php
			$rs = mysql_query("SELECT * FROM students");
			
			//COMBO BOX FOR ID'S
			while($row = mysql_fetch_array($rs) ){
				
				echo "<option value='".$row['student_id']."'>".$row['student_id']."</option>"."</td>";
			}
			?>
		</select>
		<br/>
		Type of mark:
		<select name="mark">
			<option value="">--Type Of Mark--</option>
			<option value="test_1">Test 1</option>
			<option value="test_2">Test 2</option>
			<option value="assignment">Assignment</option>
			<option value="project">Project</option>
			<option value="paper_1">Paper 1</option>
			<option value="paper_2">Paper 2</option>
		</select>
		&nbsp; <input type="text" name="percent" />
		<br/>
		<button type="submit">Update</button>&nbsp;<button type="reset">Reset</button><br/>
		<?php echo $msg; echo $error; ?>
	</form>
</div>

<?php
	mysql_close($con);
?>

<div id = "footer">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
	developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>
