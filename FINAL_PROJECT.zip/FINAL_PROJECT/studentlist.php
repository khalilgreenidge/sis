<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
<link rel="shortcut icon" href="imgs/titleimg.gif" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

<div id = "header">
	<img src="imgs/bcclogo.gif" alt="log" />
	<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
	<p class="msg" style="float: right;">Signed in as <?php echo "<b>".ucfirst($_SESSION["user"]).".</b>";?></p>
</div>

<div id = "menu">
<?php include("menu.php") ?>
</div>

<div id = "content">
	<h1>Barbados Community College - Tutor Portal</h1>
	
	<h2>LIST OF STUDENTS</h2>
<form>
<?php
$rowNum = $rem = 0;

$con = mysql_connect("localhost", "root", "") or die(mysql_error());
mysql_select_db("my course") or die(mysql_error());

$result = mysql_query("SELECT * FROM students ORDER BY last_name ASC");

echo "<table border = '1'>
<tr>
<th>Student Identification Number</th>
<th>First Name </th>
<th>Last Name</th>
<th>Test 1</th>
<th>Test 2</th>
<th>Assignment</th>
<th>Project</th>
<th>Paper 1 %</th>
<th>Paper 2%</th>
</tr>";

while($row = mysql_fetch_array($result)){
	$rowNum++;
	$rem = $rowNum % 2;
			
	//CREATES AN ALTERNATING COLOUR
	if($rem == 0){
		echo "<tr style='background-color: #FA8258;'>";
		echo "<td>" . $row['student_id'] . "</td>";
		echo "<td>" . $row['first_name'] . "</td>";
		echo "<td>" . $row['last_name'] . "</td>";
		echo "<td style='text-align: right'>".$row['test_1']."</td>";
		echo "<td style='text-align: right'>".$row['test_2']."</td>";
		echo "<td style='text-align: right'>".$row['assignment']."</td>";
		echo "<td style='text-align: right'>".$row['project']."</td>";
		echo "<td style='text-align: right'>".$row['paper_1']."</td>";
		echo "<td style='text-align: right'>".$row['paper_2']."</td>";	
		echo "<tr>";
	}
	else {
		echo "<tr>";
		echo "<td>".$row['student_id']."</td>";
		echo "<td>".$row['first_name']."</td>";
		echo "<td>".$row['last_name']."</td>";		
		echo "<td style='text-align: right'>".$row['test_1']."</td>";
		echo "<td style='text-align: right'>".$row['test_2']."</td>";
		echo "<td style='text-align: right'>".$row['assignment']."</td>";
		echo "<td style='text-align: right'>".$row['project']."</td>";
		echo "<td style='text-align: right'>".$row['paper_1']."</td>";
		echo "<td style='text-align: right'>".$row['paper_2']."</td>";	
	}
}
echo "</table>";


mysql_close();

?>
</form>
</div>


<div id = "footer">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
	developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>
