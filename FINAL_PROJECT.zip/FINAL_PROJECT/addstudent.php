<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
<link rel="shortcut icon" href="imgs/titleimg.gif" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

<div id = "header">
	<img src="imgs/bcclogo.gif" alt="log" />
	<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
	<p class="msg" style="float: right;">Signed in as <?php echo "<b>".ucfirst($_SESSION["user"]).".</b>";?></p>
</div>

<div id = "menu">
<?php include("menu.php") ?>
</div>

<?php
	$msg = $id = $firstname = $lastname = $error = "";
	
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		
		//GET FORM DATA
		$id = $_POST["ID"];
		$firstname = $_POST["firstname"];
		$lastname = $_POST["lastname"];
		
		//ESTABLISH CONNECTION
		$con = mysql_connect("localhost", "root", "");
		
		//CONNECT TO DB
		$db = mysql_select_db("my course");
		
		//EXTRACT RESULTSET
		$rs = mysql_query("INSERT INTO students values($id, '$firstname', '$lastname', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)");
		
		if(!$con || !$db || !$rs){
			$error = "Error: ".mysql_error();
			
		}
		else{
			$msg = "Student information saved!";
					
		}
	}
	
?>

<div id = "content">
	<h1>Add The Student</h1>
	<br/>
	<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
		Student ID: <input type="text" name="ID" /> <br/>
		First Name: <input type="text" name="firstname" /><br/>
		Last Name: <input type="text" name="lastname" /><br/>
		<button type="submit">Save</button><input type="reset" value="Reset" /><br/>
		<?php echo $msg; echo $error; ?>
	</form>
</div>


<div id = "footer">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
	developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>
