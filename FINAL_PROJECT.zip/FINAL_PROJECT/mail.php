<!--
For HELP ON CONFIGURATION
http://digiex.net/guides-reviews/guides-tutorials/application-guides/544-configuring-php-under-windows-use-gmail-external-smtp-server-ssl.html#post25126

NEEDS CONFIGURATION IN ORDER TO WORK
-->

<?php
	//GET FORM DATA
	$tutorid = $_POST["ID"];
	$firstname = $_POST["firstname"];
	$lastname = $_POST["lastname"];
	$tutoruser = $_POST["user"];
	$tutorpwd = $_POST["pwd"];
	$email = $_POST["email"];
	$gender = $_POST["gender"];

	$subject = "Barbados Community College - Tutor Portal";
	
	// the message
	$msg = "<!DOCTYPE html>
<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' type = 'text/css'>
</head>
<body style=\"
	font-family: 'Open Sans', sans-serif;
	background-color: #e4e4e4;\">

<div id = \"wrap\" style=\"
	
	display: block;
	margin: 0 auto;
	height: auto;
	width: 800px;
	background-color: #FFFFFF;
	box-shadow: 0px 5px 30px #888888;\">

<div id = \"header\">
	<img src= \"http://bcc.edu.bb/images/logo-web.gif\" alt=\"log\" />
	<span style=\"float: right; padding-top: 10px;\"><img src=\"http://thetutortrust.org/images/portal-main-graphic.png\" alt=\"portal photo\" width=\"\" height=\"150px\"/></span>
</div>
<hr/>
<br/>
<br/>
<br/>
<div id = \"content\">
	<h1>BCC Tutor Portal</h1>
	
	<h3>Confirmation<h3/><br/></br/>
	
	<p>Dear ".$gender." ".$firstname." ".$lastname.",
		Please click the button below to confirm your account:
	</p>
	
	<form method='post' action=\"http://localhost:8000/mydocs/FINAL_PROJECT/confirm.php\" target=\"_blank\">
		<input type='hidden' name='ID' value='$tutorid'/>
		<input type='hidden' name='user' value='$tutoruser'/>
		<input type='hidden' name='pwd' value='$tutorpwd'/>
		<button style='background-color: rgba(205,205,205,.82); 
		color: #000; border: 0;' type=\"submit\">Click here to confirm your account </button>
	</form>
	

</div>
<br/>
<br/>
<br/>

<div id = \"footer\" style=\"height: 80px;
	line-height: 20px;text-align: center;background: #848484;
	color: #ccc;font-size: 11px;\">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - ".date("Y").", The Barbados Community College<br/>
	Developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>";

	// use wordwrap() if lines are longer than 70 characters
	//$msg = wordwrap($msg,70);
	
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= "Date: ".date("Y/m/d, h:i:sa")."\r\n";
	$headers .= "From: BCC Tutor Portal < no-reply@BCCTutorPortal.com>";

	// send email
	if(mail($email,$subject,$msg, $headers)){
		//SHOW MESSAGE
		$msg2 = "Mail Sent!";
		
		//NB *** THE BUTTON ONLY WORKS IN GMAIL AND NOT HOTMAIL!!
	}
	else
		$msg2 = "Error";
	
	
?>

<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
		<!--REDIRECTS TO LOGIN PAGE-->
	<meta http-equiv="Refresh" content="5; URL=login.php" />
	<link rel="shortcut icon" href="imgs/titleimg.gif" />
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
	<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

<div id = "header">
	<img src="imgs/bcclogo.gif" alt="log" />
	<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
</div>

<hr class="bar"/>

<div id = "content">
	<h1><?php echo $msg2; ?></h1>
	
	<p>Check your email to confirm the account</p>
</div>


<div id = "footer">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
	Developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>