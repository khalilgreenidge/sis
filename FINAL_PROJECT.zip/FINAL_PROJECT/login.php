<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
<link rel="shortcut icon" href="imgs/titleimg.gif" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

	<div id = "header">
		<img src="imgs/bcclogo.gif" alt="logo" />
		<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
	</div>

	<div id = "menu">
	<?php
		
	if(empty($_SESSION)){
		echo"<br/>
		<br/>
		<br/>";
	}
	else{
		 include("menu.php");
	}
	?>
	</div>

	<div id = "content">
		<h1>Barbados Community College - Tutor Portal</h1>
		<div id="slideshow">
		
		</div>
		<br/>
		<br/>
		<?php
			$user = $password = $msg = $dbuser = $dbpassword = "";
			
						
			//CHECKS IF PERSON HAS NOT LOGGED IN
			
			if(empty($_SESSION["login"])){
				//PERSON HAS NOT LOGGED IN SO SHOW LOGIN FORM 
				echo "
				<div id=\"login\">
				<form action='".$_SERVER['PHP_SELF']."' method=\"post\">
					User Name: <input type=\"text\" name=\"user\" />
					Password: <input type=\"password\" name=\"pwd\" /> <button type=\"submit\">Login</button>
				";	

				
				if( $_SERVER["REQUEST_METHOD"] == "POST"){

					$user = $_POST["user"];
					$password = $_POST["pwd"];
								
					//ESTABLISH CONNECT
					$con = mysql_connect("localhost", "root", "");
					
					//CONNECT TO DB
					$db = mysql_select_db("my course");
					
					//MAKE A QUERY
					$rs = mysql_query("SELECT * FROM tutors WHERE user='$user' ");
					
					if(!$con || !$db || !$rs){
						$msg = "Error: ".mysql_error();
					}
					else{
						//SHOW MESSAGE TO USER
						$msg = "Account confirmed!";
						
						//GET DATA USERNAME AND PASSWORD FROM DB
						while($row = mysql_fetch_array($rs)){
							$dbuser = $row["user"];
							$dbpassword = $row["password"];
						}
											
					}		
					
						//VERIFICATION
						if($user == $dbuser && $password == $dbpassword){
							$_SESSION["login"] = "yes";
							$_SESSION["user"] = $user;
							header("Location: mainmenu.php");
						}
						else{
							$msg = "incorrect/username password";
						}
				}
				
				echo "</form>
				<br/>".$msg.			
				"</div>";
				echo "<br/>";
				echo "<h3>Not yet signed up?</h3><br/>
				<form action='signup.php'>
					<button type='submit'>Sign up</button>
				</form>
				";
			}
			//PERSON HAS ALREADY SIGNED IN
			else{
				echo "<h2>Login</h2> <br />
					<p>You are already signed in as <b>".ucfirst($_SESSION["user"]).".</b></p>
					<form action='logout.php' method='get'>
						<button type='submit'>Log out</button>
					</form>";
			}	

		?>		
	</div>		
	<div id = "footer">
		<h3>Barbados Community College - Tutor Portal</h3>
		<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
		developed by: Khalil Greenidge & Romario Bates</p>
		</p>
	</div>

</div>
</body>
</html>