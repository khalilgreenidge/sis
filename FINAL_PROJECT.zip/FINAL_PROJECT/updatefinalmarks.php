<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
<link rel="shortcut icon" href="imgs/titleimg.gif" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

<div id = "header">
	<img src="imgs/bcclogo.gif" alt="log" />
	<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
	<p class="msg" style="float: right;">Signed in as <?php echo "<b>".ucfirst($_SESSION["user"]).".</b>";?></p>
</div>

<div id = "menu">
<?php include("menu.php"); ?>
	
</div>

<div id = "content">
	
	<h1>Update the final marks for the students</h1>
	
	<?php
	$msg = $id = $mark = $percent = $error = "";
	
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		
		//GET FORM DATA
		$id = $_POST["student_id"];
		$paper1 = $_POST["paper1"];
		$paper2 = $_POST["paper2"];
		
		//ESTABLISH CONNECTION
		$con = mysql_connect("localhost", "root", "");
		
		//CONNECT TO DB
		$db = mysql_select_db("my course");
		
		//EXTRACT RESULTSET
		$rs = mysql_query("UPDATE students SET paper_1=$paper1, paper_2=$paper2 WHERE student_id=$id ");
		
		if(!$con || !$db || !$rs){
			$error = "Error: ".mysql_error();
			
		}
		else{
			$msg = "Student information has been update!";
		}
	}
?>
	
<form action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method = "post">
<?php 

$rowNum = $rem = 0;

$con = mysql_connect("localhost","root","") or die(mysql_error());

mysql_select_db("my course") or die(mysql_error());

$result = mysql_query("SELECT * FROM students ORDER BY last_name ASC") or die (mysql_error());

		echo "<table border='1'>
		<tr>
		<th>Student ID</th><th>First Name</th><th>Last Name</th>
		<th>Test 1%</th><th>Test 2%</th><th>Assignment %</th><th>Project %</th><th>Paper 1 %</th><th>Paper 2%</th>
		</tr>
		";

while($row = mysql_fetch_array($result)){
	$rowNum++;
	$rem = $rowNum % 2;
			
	//CREATES AN ALTERNATING COLOUR
	if($rem == 0){
		echo "<tr style='background-color: #FA8258;'>";
		echo "<td>" . $row['student_id'] . "</td>";
		echo "<td>" . $row['first_name'] . "</td>";
		echo "<td>" . $row['last_name'] . "</td>";
		echo "<td style='text-align: right'>".$row['test_1']."</td>";
		echo "<td style='text-align: right'>".$row['test_2']."</td>";
		echo "<td style='text-align: right'>".$row['assignment']."</td>";
		echo "<td style='text-align: right'>".$row['project']."</td>";
		echo "<td style='text-align: right'>".$row['paper_1']."</td>";
		echo "<td style='text-align: right'>".$row['paper_2']."</td>";	
		echo "<tr>";
	}
	else {
		echo "<tr>";
		echo "<td>".$row['student_id']."</td>";
		echo "<td>".$row['first_name']."</td>";
		echo "<td>".$row['last_name']."</td>";		
		echo "<td style='text-align: right'>".$row['test_1']."</td>";
		echo "<td style='text-align: right'>".$row['test_2']."</td>";
		echo "<td style='text-align: right'>".$row['assignment']."</td>";
		echo "<td style='text-align: right'>".$row['project']."</td>";
		echo "<td style='text-align: right'>".$row['paper_1']."</td>";
		echo "<td style='text-align: right'>".$row['paper_2']."</td>";	
	}
}	
	
echo "</table>";

$result1 = mysql_query("SELECT student_id FROM students") or die(mysql_error());

echo "
<br/>
<hr/>
<br/>
<select name =\"student_id\">";
while($row = mysql_fetch_array($result1)){
	echo"<option value = ".$row["student_id"].">".$row["student_id"]."</option>";
	}

mysql_close();
echo"</select>";
?>

<br/>
<br/>

Paper 1: <input type = "text" name = "paper1"> <br/>
Paper 2: <input type = "text" name = "paper2"> <br/>
<button type = "Submit">Update</button>&nbsp;<button type = "reset" value = "Reset">Reset</button>
</form>
<br/>
<?php echo $msg; echo $error; ?>
</div>
<br/>
<div id = "footer">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
	developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>
