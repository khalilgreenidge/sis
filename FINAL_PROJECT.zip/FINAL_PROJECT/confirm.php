<html>
<head>
<title>Barbados Community College - Tutor Portal</title>
		<!--REDIRECTS TO LOGIN PAGE-->
	<meta http-equiv="Refresh" content="5; URL=login.php" />
	<link rel="shortcut icon" href="imgs/titleimg.gif" />
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
	<link href = 'http://fonts.googleapis.com/css?family=Open+Sans' rel = 'stylesheet' = type = 'text/css'>
</head>
<body>

<div id = "wrap">

<div id = "header">
	<img src="imgs/bcclogo.gif" alt="log" />
	<span style="float: right; padding-top: 10px;"><img src="imgs/portal.png" alt="portal photo" width="" height="150px"/></span>
</div>



<div id = "content">
	<h1>Success</h1>
	
<?php
	//SAVE USER TO DATABASE
	$id = $_POST["ID"];
	$user = $_POST["user"];
	$pwd = $_POST["pwd"];
	
	//ESTABLISH CONNECT
	$con = mysql_connect("localhost", "root", "");
	
	//CONNECT TO DB
	$db = mysql_select_db("my course");
	
	//MAKE A QUERY
	$rs = mysql_query("INSERT INTO tutors VALUES('$user',$id, '$pwd') ");
	
	if(!$con || !$db ||$rs){
		$msg = "Error: ".mysql_error();
	}
	else{
		$msg = "Account confirmed!";
	}
	
?>

	<p><?php echo $msg; ?></p>
</div>

<div id = "footer">
	<h3>Barbados Community College - Tutor Portal</h3>
	<p>&copy; 2000 - <?php echo date("Y"); ?>, The Barbados Community College<br/>
	Developed by: Khalil Greenidge & Romario Bates</p>
	</p>
</div>

</body>
</html>